import asyncio
import json
import logging

import requests
import websockets
from initGates.configGate import save_config


async def web_socket_auth(host: str, token: str):
    url = host + '/ws/speakerapi/init/checkauth/'

    try:
        async with websockets.connect(url) as ws:
            await ws.send(json.dumps({"token": token}))
            msg = await ws.recv()
            return msg
    except websockets.exceptions.ConnectionClosedError:
        return None


def init(object_storage):
    object_storage.speakSpeech.play(
        "Колонка еще не авторизована. "
        "Сейчас я скажу тебе код из 6 цифр, "
        "его надо ввести в окне подключения колонки в medsenger. ",
        cache=True)

    answer = requests.post(object_storage.host_http + '/speakerapi/init/',
                           json={'version': object_storage.version}).json()

    config = object_storage.config
    config['token'] = answer['token']
    save_config(config, object_storage.config_filename)

    object_storage.speakSpeech.play(
        "Итак, твой код: {}".format(" - ".join(list(str(answer["code"])))))

    object_storage.pixels.think()

    authed = None
    while authed is None:
        authed = asyncio.get_event_loop().run_until_complete(
            web_socket_auth(object_storage.host_ws, object_storage.token))

    if authed != 'OK':
        raise RuntimeError("Auth confirmation failed, '{}'".format(authed))

    logging.info("Authentication passed")
    object_storage.speakSpeech.play(
        "Отлично! Устройство настроено. Чтобы узнать, о моих возможностях, спросите, 'что ты умеешь?'",
        cache=True
    )

    return config


def auth_gate(object_storage):
    if not object_storage.token:
        logging.info("Token does not exist, authentication")
        object_storage.config = init(object_storage)

    return object_storage
