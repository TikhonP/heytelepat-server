echo $1 | sudo tee -a /etc/wpa_supplicant/wpa_supplicant.conf > /dev/null
